package gfx.tick3;

public class Tick3 {
    public static void usage() {
        System.err.println("USAGE: <tick3> --input INPUT [--output OUTPUT]");
        System.exit(-1);
    }

    public static void main(String[] args) {
        //argument parsing
        if (args.length % 2 != 0)
            usage();

        String input = null, output = null;
        for (int i = 0; i < args.length; i += 2) {
            switch (args[i]) {
            case "--input":
                input = args[i + 1];
                break;
            case "--output":
                output = args[i + 1];
                break;
            default:
                System.err.println("unknown option: " + args[i]);
                usage();
            }
        }

        if (input == null) {
            System.err.println("required arguments not present");
            usage();
        }

        OpenGLApplication app = null;
        try {
            app = new OpenGLApplication(input);
            if (output != null) {
                app.render();
                app.takeScreenshot(output);
            } else {
                app.run();
            }
        } finally {
            if (app != null)
                app.stop();
        }
    }
}
