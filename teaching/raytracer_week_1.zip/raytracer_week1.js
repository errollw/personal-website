// we render into a square image img_w_px pixels across
var img_w_px = 500

// find the canvas in the webpage, and get access to its data
var canvas = document.getElementById("scrn_canv")
var context2d = canvas.getContext("2d")
var img_data = context2d.getImageData(0, 0, img_w_px, img_w_px)

// set the size of the canvas
canvas.width = canvas.height = img_w_px;

// this function sets the color of pixels in the canvas data
function setPixel(x, y, r, g, b) {
	var i = (y * img_data.width + x) * 4;
	img_data.data[i++] = r;
	img_data.data[i++] = g;
	img_data.data[i++] = b;
	img_data.data[i] = 255;
}

// ------------------------------------------------------------
// ONLY MODIFY CODE BELOW THIS POINT
// ------------------------------------------------------------

// the position of the camera
var cam_pos = new Vector(0,0,-3);

// the direction the camera is looking in
var cam_dir = new Vector(0,0,1).unit();

// camera's up vector, going up the image plane
var up_vec = cam_dir.cross(new Vector(1,0,0)).unit();

// the vector along the edge of the image plane
var left_vec = up_vec.cross(cam_dir).unit();

// the distance from the camera to the image plane
var cam_img_dist = 2.5;

// the width of the image plane
var img_w = 1.0;

// the top left of the image plane
var img_tl = cam_pos.add(cam_dir.multiply(cam_img_dist))
					.subtract(left_vec.multiply(img_w/2.0))
					.subtract(up_vec.multiply(img_w/2.0));

function Sphere(center, radius) {

	this.center = center;
	this.radius = radius;

	this.hitTest = function(origin, ray){
		return false;
	}
}

var s = new Sphere(new Vector(0,0,3), 1)
var light_pos = new Vector(1,-1,1)

// loop over each pixel to be rendered
for (y=0; y<canvas.height; y++){
	for(x=0; x<canvas.width; x++){

		// TODO: calculate position of pixel in image plane

		// TODO: use that to get an equation for a ray

		// TODO: check for intersection with Sphere s, and shade with Phong

		setPixel(x, y, x, y, 128)
	}
}


// ------------------------------------------------------------
// ONLY MODIFY CODE ABOVE THIS POINT
// ------------------------------------------------------------


//rendering complete
console.log("### RENDERING COMPLETE ###")

// finally put the modified image data back into the canvas element
context2d.putImageData(img_data, 0, 0);